/* ------------------------------ TASK 4 -----------------------------------
Parašykite JS kodą, vartotjui atėjus į tinkaį kreipsis į cars.json failą
ir iš atvaizduos visus automobilių gamintojus ir pagamintus modelius. 
Kiekvienas gamintojas turės savo atvaizdavimo "kortelę", kurioje bus 
nurodomas gamintojas ir jo pagaminti modeliai.


Pastaba: Informacija apie automobilį (brand) (jo kortelė) bei turi turėti 
bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = 'cars.json';

function getJson(){
    fetch(ENDPOINT)
    .then(js21_jonsResp => js21_jonsResp.json())
    .then(js21_jsonData  => {
        let output = "";
        js21_jsonData.forEach((item,index)=>{
            output += 
            `<h2> ${item.brand}</h2>
            <li> ${item.models}</li>`;
        })
        document.getElementById("output").innerHTML = output;
    })}

       fetch(ENDPOINT)
        .then(js21_getApiResp => {
            if(js21_getApiResp.ok){
                console.log("duomenys gauti");
            return js21_getApiResp.json()
            }
            else{console.log("kazkas negerai")}
        })
        .then(js21_getApiData => console.log(js21_getApiData))
        .catch(err => console.log("nepavyko,err"));

        getJson();