/* ------------------------------ TASK 3 -----------------------------------
Parašykite JS kodą, kuris leis vartotojui paspaudus ant mygtuko "Show users"
pamatyti vartotojus iš Github API (endpoint'as pateiktas žemiau).

Paspaudus mygtuką "Show users":
1. Pateikiamas informacijos atvaizdavimas <div id="output"></div> bloke
1.1. Infrmacija, kuri pateikiama: "login" ir "avatar_url" reikšmės (kortelėje)
2. Žinutė "Press "Show Users" button to see users" turi išnykti;
"
Pastaba: Informacija apie user'į (jo kortelė) bei turi turėti bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = 'https://api.github.com/users';
const btn = document.getElementById("btn");

btn.addEventListener("click",getData);

    function getData(){
    fetch(ENDPOINT)
    .then(js21_jsonResp => js21_jsonResp.json())
    .then(js21_jsonData => {
        let output = "";
        js21_jsonData.forEach((item,index)=>{
            output +=
            `<div> 
                User Login: <h2>${item.login}</h2>
                <img src="${item.avatar_url}">
            </div>`
            ;
        })
        document.getElementById("output").innerHTML = output;
    })
    }

    